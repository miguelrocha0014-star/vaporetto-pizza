# Vaporetto – Landing Page

Landing page da pizzaria Vaporetto (Samambaia Norte, Brasília-DF).

## Publicar no GitHub Pages
1. Crie um repositório e envie estes arquivos para a branch `main`.
2. Vá em **Settings → Pages**.
3. Em **Source**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`.
4. Aguarde alguns minutos: o site ficará em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

## Observações
- Os links do WhatsApp (`wa.me/?text=...`) estão sem número. Adicione o número com DDI, por exemplo `https://wa.me/5561999999999?text=...`.
